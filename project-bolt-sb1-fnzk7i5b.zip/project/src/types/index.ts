export interface Skill {
  id: string;
  name: string;
  category: SkillCategory;
}

export type SkillCategory = 
  | 'technical' 
  | 'soft' 
  | 'domain' 
  | 'tool' 
  | 'language';

export interface Company {
  id: string;
  name: string;
  logo: string;
  description: string;
  location: string;
  website: string;
  skills: string[];
  openPositions: JobPosition[];
  size: CompanySize;
  industry: string;
}

export type CompanySize = 'startup' | 'small' | 'medium' | 'large' | 'enterprise';

export interface JobPosition {
  id: string;
  title: string;
  description: string;
  skills: string[];
  experience: string;
  location: string;
}

export interface UserProfile {
  skills: string[];
  location: string;
  experience: number;
}