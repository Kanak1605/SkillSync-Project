import { Skill } from '../types';

export const skillsList: Skill[] = [
  // Technical Skills
  { id: '1', name: 'JavaScript', category: 'technical' },
  { id: '2', name: 'React', category: 'technical' },
  { id: '3', name: 'Node.js', category: 'technical' },
  { id: '4', name: 'TypeScript', category: 'technical' },
  { id: '5', name: 'Python', category: 'technical' },
  { id: '6', name: 'Java', category: 'technical' },
  { id: '7', name: 'C#', category: 'technical' },
  { id: '8', name: 'SQL', category: 'technical' },
  { id: '9', name: 'MongoDB', category: 'technical' },
  { id: '10', name: 'AWS', category: 'technical' },
  { id: '11', name: 'Azure', category: 'technical' },
  { id: '12', name: 'Docker', category: 'technical' },
  { id: '13', name: 'Kubernetes', category: 'technical' },
  { id: '14', name: 'Machine Learning', category: 'technical' },
  { id: '15', name: 'Data Science', category: 'technical' },
  { id: '16', name: 'AI', category: 'technical' },
  
  // Soft Skills
  { id: '17', name: 'Communication', category: 'soft' },
  { id: '18', name: 'Leadership', category: 'soft' },
  { id: '19', name: 'Problem Solving', category: 'soft' },
  { id: '20', name: 'Teamwork', category: 'soft' },
  { id: '21', name: 'Time Management', category: 'soft' },
  { id: '22', name: 'Adaptability', category: 'soft' },
  
  // Domain Skills
  { id: '23', name: 'Finance', category: 'domain' },
  { id: '24', name: 'Healthcare', category: 'domain' },
  { id: '25', name: 'E-commerce', category: 'domain' },
  { id: '26', name: 'Education', category: 'domain' },
  { id: '27', name: 'Manufacturing', category: 'domain' },
  
  // Tools
  { id: '28', name: 'Photoshop', category: 'tool' },
  { id: '29', name: 'Figma', category: 'tool' },
  { id: '30', name: 'JIRA', category: 'tool' },
  { id: '31', name: 'Git', category: 'tool' },
  { id: '32', name: 'VS Code', category: 'tool' },
  
  // Languages
  { id: '33', name: 'English', category: 'language' },
  { id: '34', name: 'Hindi', category: 'language' },
  { id: '35', name: 'Tamil', category: 'language' },
  { id: '36', name: 'Telugu', category: 'language' },
  { id: '37', name: 'Kannada', category: 'language' },
  { id: '38', name: 'Malayalam', category: 'language' },
];

export const getSkillById = (id: string): Skill | undefined => {
  return skillsList.find(skill => skill.id === id);
};

export const getSkillByName = (name: string): Skill | undefined => {
  return skillsList.find(skill => skill.name.toLowerCase() === name.toLowerCase());
};

export const getSkillsByCategory = (category: string): Skill[] => {
  return skillsList.filter(skill => skill.category === category);
};

export const searchSkills = (query: string): Skill[] => {
  const lowercaseQuery = query.toLowerCase();
  return skillsList.filter(skill => 
    skill.name.toLowerCase().includes(lowercaseQuery)
  );
};