import { Company } from '../types';

export const companiesList: Company[] = [
  {
    id: '1',
    name: 'TechNova Solutions',
    logo: 'https://images.pexels.com/photos/2312369/pexels-photo-2312369.jpeg?auto=compress&cs=tinysrgb&w=100',
    description: 'A cutting-edge tech company specializing in AI solutions and cloud services for enterprises.',
    location: 'Bangalore',
    website: 'https://technova.example.com',
    skills: ['1', '2', '3', '4', '10', '14', '15', '16', '19'],
    size: 'large',
    industry: 'Information Technology',
    openPositions: [
      {
        id: '101',
        title: 'Senior Frontend Developer',
        description: 'Responsible for building responsive web applications using React.',
        skills: ['1', '2', '4'],
        experience: '3-5 years',
        location: 'Bangalore',
      },
      {
        id: '102',
        title: 'Machine Learning Engineer',
        description: 'Develop and implement ML models for our AI platform.',
        skills: ['5', '14', '15', '16'],
        experience: '2-4 years',
        location: 'Bangalore',
      },
    ],
  },
  {
    id: '2',
    name: 'CloudMatrix',
    logo: 'https://images.pexels.com/photos/2451616/pexels-photo-2451616.jpeg?auto=compress&cs=tinysrgb&w=100',
    description: 'Leading provider of cloud infrastructure and DevOps solutions.',
    location: 'Hyderabad',
    website: 'https://cloudmatrix.example.com',
    skills: ['3', '10', '11', '12', '13', '19', '20'],
    size: 'medium',
    industry: 'Cloud Services',
    openPositions: [
      {
        id: '201',
        title: 'DevOps Engineer',
        description: 'Implement and maintain CI/CD pipelines and cloud infrastructure.',
        skills: ['10', '12', '13'],
        experience: '2-5 years',
        location: 'Hyderabad',
      },
    ],
  },
  {
    id: '3',
    name: 'FinEdge Systems',
    logo: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=100',
    description: 'Innovative fintech company providing solutions for banking and financial services.',
    location: 'Mumbai',
    website: 'https://finedge.example.com',
    skills: ['1', '4', '6', '8', '23'],
    size: 'small',
    industry: 'Fintech',
    openPositions: [
      {
        id: '301',
        title: 'Fullstack Developer',
        description: 'Develop and maintain financial applications using Java and React.',
        skills: ['1', '2', '6'],
        experience: '3-6 years',
        location: 'Mumbai',
      },
      {
        id: '302',
        title: 'Database Administrator',
        description: 'Manage and optimize databases for financial applications.',
        skills: ['8'],
        experience: '4-7 years',
        location: 'Mumbai',
      },
    ],
  },
  {
    id: '4',
    name: 'HealthTech Innovations',
    logo: 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg?auto=compress&cs=tinysrgb&w=100',
    description: 'Developing cutting-edge healthcare technology solutions to improve patient care.',
    location: 'Delhi',
    website: 'https://healthtech.example.com',
    skills: ['5', '14', '15', '16', '24'],
    size: 'startup',
    industry: 'Healthcare',
    openPositions: [
      {
        id: '401',
        title: 'Data Scientist',
        description: 'Analyze healthcare data to derive insights and build predictive models.',
        skills: ['5', '14', '15'],
        experience: '2-4 years',
        location: 'Delhi',
      },
    ],
  },
  {
    id: '5',
    name: 'RetailX',
    logo: 'https://images.pexels.com/photos/5076531/pexels-photo-5076531.jpeg?auto=compress&cs=tinysrgb&w=100',
    description: 'E-commerce platform revolutionizing the retail experience with technology.',
    location: 'Bangalore',
    website: 'https://retailx.example.com',
    skills: ['1', '2', '3', '4', '25'],
    size: 'large',
    industry: 'E-commerce',
    openPositions: [
      {
        id: '501',
        title: 'Frontend Developer',
        description: 'Build responsive and intuitive user interfaces for our e-commerce platform.',
        skills: ['1', '2', '4'],
        experience: '1-3 years',
        location: 'Bangalore',
      },
      {
        id: '502',
        title: 'Backend Developer',
        description: 'Develop robust backend systems for handling e-commerce operations.',
        skills: ['3', '6', '8'],
        experience: '2-4 years',
        location: 'Bangalore',
      },
    ],
  },
];

export const getCompanyById = (id: string): Company | undefined => {
  return companiesList.find(company => company.id === id);
};

export const getCompaniesBySkill = (skillId: string): Company[] => {
  return companiesList.filter(company => 
    company.skills.includes(skillId)
  );
};

export const getCompaniesByLocation = (location: string): Company[] => {
  return companiesList.filter(company => 
    company.location.toLowerCase() === location.toLowerCase()
  );
};

export const getCompaniesBySkills = (skillIds: string[]): Company[] => {
  if (!skillIds.length) return companiesList;
  
  return companiesList.filter(company => 
    skillIds.some(skillId => company.skills.includes(skillId))
  ).sort((a, b) => {
    // Sort by most matching skills
    const aMatches = a.skills.filter(skill => skillIds.includes(skill)).length;
    const bMatches = b.skills.filter(skill => skillIds.includes(skill)).length;
    return bMatches - aMatches;
  });
};