import React from 'react';
import { Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Zap className="h-8 w-8 text-blue-800" />
            <span className="ml-2 text-xl font-bold text-blue-900">SkillSync</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-blue-800 px-3 py-2 text-sm font-medium">
              Find Companies
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-800 px-3 py-2 text-sm font-medium">
              Explore Skills
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-800 px-3 py-2 text-sm font-medium">
              My Profile
            </a>
          </nav>
          
          <div className="hidden md:flex items-center">
            <button
              type="button"
              className="bg-white hover:bg-gray-50 text-blue-800 px-4 py-2 border border-blue-800 rounded-md text-sm font-medium"
            >
              Sign In
            </button>
            <button
              type="button"
              className="ml-4 bg-blue-800 hover:bg-blue-900 text-white px-4 py-2 rounded-md text-sm font-medium"
            >
              Sign Up
            </button>
          </div>
          
          <div className="md:hidden">
            <button type="button" className="text-gray-400 hover:text-gray-500">
              <svg
                className="h-6 w-6"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;