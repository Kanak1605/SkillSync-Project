import React, { useState, useRef, useEffect } from 'react';
import { Search, ChevronDown } from 'lucide-react';
import { Skill } from '../../types';
import { searchSkills } from '../../data/skills';
import Chip from '../common/Chip';

interface SkillSelectorProps {
  selectedSkills: Skill[];
  onChange: (skills: Skill[]) => void;
  placeholder?: string;
}

const SkillSelector: React.FC<SkillSelectorProps> = ({
  selectedSkills,
  onChange,
  placeholder = 'Search for skills...',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Skill[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (searchTerm.trim()) {
      const results = searchSkills(searchTerm);
      // Filter out already selected skills
      const filteredResults = results.filter(
        (skill) => !selectedSkills.some((selected) => selected.id === skill.id)
      );
      setSearchResults(filteredResults);
    } else {
      setSearchResults([]);
    }
  }, [searchTerm, selectedSkills]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    if (!isOpen) setIsOpen(true);
  };

  const handleSelectSkill = (skill: Skill) => {
    onChange([...selectedSkills, skill]);
    setSearchTerm('');
    inputRef.current?.focus();
  };

  const handleRemoveSkill = (skillId: string) => {
    onChange(selectedSkills.filter((skill) => skill.id !== skillId));
  };

  const handleFocus = () => {
    setIsOpen(true);
  };

  const getCategoryColor = (category: string): string => {
    switch (category) {
      case 'technical': return 'blue';
      case 'soft': return 'teal';
      case 'domain': return 'orange';
      case 'tool': return 'gray';
      case 'language': return 'blue';
      default: return 'gray';
    }
  };

  return (
    <div className="relative w-full" ref={containerRef}>
      <div className="flex items-center p-2 border border-gray-300 rounded-lg bg-white focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500">
        <Search className="text-gray-400 mr-2" size={20} />
        <div className="flex flex-wrap gap-2 flex-1">
          {selectedSkills.map((skill) => (
            <Chip
              key={skill.id}
              label={skill.name}
              color={getCategoryColor(skill.category)}
              onDelete={() => handleRemoveSkill(skill.id)}
              size="md"
            />
          ))}
          <input
            ref={inputRef}
            type="text"
            className="flex-1 min-w-[120px] outline-none text-gray-700"
            placeholder={selectedSkills.length ? '' : placeholder}
            value={searchTerm}
            onChange={handleInputChange}
            onFocus={handleFocus}
          />
        </div>
        <ChevronDown
          className={`text-gray-400 transition-transform duration-200 ${
            isOpen ? 'transform rotate-180' : ''
          }`}
          size={20}
          onClick={() => setIsOpen(!isOpen)}
        />
      </div>
      
      {isOpen && (
        <div className="absolute z-10 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto">
          {searchResults.length > 0 ? (
            <ul className="py-1">
              {searchResults.map((skill) => (
                <li
                  key={skill.id}
                  className="px-4 py-2 hover:bg-gray-100 cursor-pointer flex items-center justify-between"
                  onClick={() => handleSelectSkill(skill)}
                >
                  <span>{skill.name}</span>
                  <Chip
                    label={skill.category}
                    color={getCategoryColor(skill.category)}
                    size="sm"
                    variant="outline"
                  />
                </li>
              ))}
            </ul>
          ) : searchTerm ? (
            <div className="px-4 py-3 text-sm text-gray-500">
              No skills found. Try a different search term.
            </div>
          ) : (
            <div className="px-4 py-3 text-sm text-gray-500">
              Start typing to search for skills
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SkillSelector;