import React from 'react';
import { X } from 'lucide-react';

interface ChipProps {
  label: string;
  onDelete?: () => void;
  variant?: 'default' | 'outline' | 'filled';
  color?: 'blue' | 'teal' | 'orange' | 'gray';
  size?: 'sm' | 'md';
  className?: string;
}

const Chip: React.FC<ChipProps> = ({
  label,
  onDelete,
  variant = 'default',
  color = 'blue',
  size = 'md',
  className = '',
}) => {
  const baseStyles = 'inline-flex items-center rounded-full font-medium transition-colors';
  
  const variantStyles = {
    default: {
      blue: 'bg-blue-100 text-blue-800',
      teal: 'bg-teal-100 text-teal-800',
      orange: 'bg-orange-100 text-orange-800',
      gray: 'bg-gray-100 text-gray-800',
    },
    outline: {
      blue: 'border border-blue-500 text-blue-700 bg-transparent',
      teal: 'border border-teal-500 text-teal-700 bg-transparent',
      orange: 'border border-orange-500 text-orange-700 bg-transparent',
      gray: 'border border-gray-300 text-gray-700 bg-transparent',
    },
    filled: {
      blue: 'bg-blue-500 text-white',
      teal: 'bg-teal-500 text-white',
      orange: 'bg-orange-500 text-white',
      gray: 'bg-gray-500 text-white',
    },
  };
  
  const sizeStyles = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-3 py-1',
  };
  
  const deleteButtonStyles = {
    sm: 'ml-1 -mr-1',
    md: 'ml-1.5 -mr-1',
  };
  
  return (
    <span
      className={`
        ${baseStyles} 
        ${variantStyles[variant][color]} 
        ${sizeStyles[size]} 
        ${className}
        ${onDelete ? 'pr-1' : ''}
      `}
    >
      <span className="truncate max-w-[150px]">{label}</span>
      {onDelete && (
        <button
          type="button"
          onClick={onDelete}
          className={`
            rounded-full p-0.5 hover:bg-black/10 transition-colors
            ${deleteButtonStyles[size]}
          `}
          aria-label={`Remove ${label}`}
        >
          <X size={size === 'sm' ? 14 : 16} className="stroke-current" />
        </button>
      )}
    </span>
  );
};

export default Chip;