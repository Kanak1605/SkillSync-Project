import React, { useState } from 'react';
import { ExternalLink, MapPin, Users, ChevronDown, ChevronUp } from 'lucide-react';
import { Company } from '../../types';
import { getSkillById } from '../../data/skills';
import Chip from '../common/Chip';
import JobCard from './JobCard';

interface CompanyCardProps {
  company: Company;
  highlightSkills?: string[];
}

const CompanyCard: React.FC<CompanyCardProps> = ({ company, highlightSkills = [] }) => {
  const [expanded, setExpanded] = useState(false);

  const companySizeMap = {
    startup: 'Startup (<50)',
    small: 'Small (50-200)',
    medium: 'Medium (201-1000)',
    large: 'Large (1001-5000)',
    enterprise: 'Enterprise (5000+)',
  };

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  const getCompanySkills = () => {
    return company.skills.map(skillId => {
      const skill = getSkillById(skillId);
      return skill ? skill.name : '';
    }).filter(Boolean);
  };

  const shouldHighlight = (skillId: string) => {
    return highlightSkills.includes(skillId);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className="w-12 h-12 rounded-md overflow-hidden flex-shrink-0 bg-gray-100 flex items-center justify-center mr-4">
            <img 
              src={company.logo} 
              alt={`${company.name} logo`}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-gray-900">{company.name}</h3>
            <div className="flex items-center text-gray-600 text-sm">
              <MapPin size={14} className="mr-1" />
              <span>{company.location}</span>
              <span className="mx-2">•</span>
              <Users size={14} className="mr-1" />
              <span>{companySizeMap[company.size]}</span>
            </div>
          </div>
        </div>
        
        <p className="text-gray-700 mb-4 line-clamp-2">
          {company.description}
        </p>
        
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Key Skills</h4>
          <div className="flex flex-wrap gap-2">
            {company.skills.slice(0, 5).map(skillId => {
              const skill = getSkillById(skillId);
              if (!skill) return null;
              
              return (
                <Chip
                  key={skill.id}
                  label={skill.name}
                  variant={shouldHighlight(skillId) ? 'filled' : 'default'}
                  color={shouldHighlight(skillId) ? 'blue' : 'gray'}
                  size="sm"
                />
              );
            })}
            {company.skills.length > 5 && (
              <Chip
                label={`+${company.skills.length - 5} more`}
                variant="outline"
                color="gray"
                size="sm"
              />
            )}
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <span className="text-sm font-medium text-blue-800">
              {company.openPositions.length} Open Positions
            </span>
          </div>
          
          <div className="flex space-x-3">
            <a
              href={company.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-blue-800 flex items-center hover:text-blue-600"
            >
              Visit Website
              <ExternalLink size={14} className="ml-1" />
            </a>
            
            <button
              onClick={toggleExpanded}
              className="text-sm text-gray-600 flex items-center hover:text-gray-900"
            >
              {expanded ? (
                <>
                  Show Less
                  <ChevronUp size={16} className="ml-1" />
                </>
              ) : (
                <>
                  Show More
                  <ChevronDown size={16} className="ml-1" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
      
      {expanded && (
        <div className="border-t border-gray-200 p-6 bg-gray-50 space-y-4">
          <div>
            <h4 className="text-lg font-medium text-gray-800 mb-3">Open Positions</h4>
            <div className="space-y-3">
              {company.openPositions.map(job => (
                <JobCard 
                  key={job.id} 
                  job={job} 
                  highlightSkills={highlightSkills} 
                />
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-800 mb-2">All Skills</h4>
            <div className="flex flex-wrap gap-2">
              {getCompanySkills().map((skillName, index) => (
                <Chip
                  key={index}
                  label={skillName}
                  variant="outline"
                  color="gray"
                  size="sm"
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CompanyCard;