import React from 'react';
import { Briefcase, MapPin } from 'lucide-react';
import { JobPosition } from '../../types';
import { getSkillById } from '../../data/skills';
import Chip from '../common/Chip';

interface JobCardProps {
  job: JobPosition;
  highlightSkills?: string[];
}

const JobCard: React.FC<JobCardProps> = ({ job, highlightSkills = [] }) => {
  const shouldHighlight = (skillId: string) => {
    return highlightSkills.includes(skillId);
  };

  return (
    <div className="bg-white rounded-md border border-gray-200 p-4 hover:shadow-sm transition-shadow">
      <div className="flex justify-between items-start mb-2">
        <h5 className="text-base font-medium text-gray-900">{job.title}</h5>
        <div className="flex items-center text-sm text-gray-600">
          <Briefcase size={14} className="mr-1" />
          <span>{job.experience}</span>
        </div>
      </div>
      
      <div className="flex items-center text-sm text-gray-600 mb-3">
        <MapPin size={14} className="mr-1" />
        <span>{job.location}</span>
      </div>
      
      <p className="text-sm text-gray-700 mb-3 line-clamp-2">
        {job.description}
      </p>
      
      <div>
        <h6 className="text-xs font-medium text-gray-700 mb-1.5">Required Skills</h6>
        <div className="flex flex-wrap gap-1.5">
          {job.skills.map(skillId => {
            const skill = getSkillById(skillId);
            if (!skill) return null;
            
            return (
              <Chip
                key={skill.id}
                label={skill.name}
                variant={shouldHighlight(skillId) ? 'filled' : 'default'}
                color={shouldHighlight(skillId) ? 'blue' : 'gray'}
                size="sm"
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default JobCard;