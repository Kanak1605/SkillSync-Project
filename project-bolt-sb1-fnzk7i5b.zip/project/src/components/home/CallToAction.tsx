import React from 'react';
import Button from '../common/Button';

const CallToAction: React.FC = () => {
  return (
    <section className="bg-blue-800 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold text-white mb-4">
          Ready to find companies that need your skills?
        </h2>
        <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8">
          Join thousands of professionals who have used SkillSync to discover their perfect company match in India.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <Button
            variant="accent"
            size="lg"
          >
            Get Started for Free
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white/10"
          >
            Contact Sales
          </Button>
        </div>
        
        <p className="mt-8 text-blue-200 text-sm">
          No credit card required. Start matching with companies today.
        </p>
      </div>
    </section>
  );
};

export default CallToAction;