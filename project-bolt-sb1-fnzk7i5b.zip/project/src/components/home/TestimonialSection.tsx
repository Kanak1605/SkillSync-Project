import React from 'react';

const testimonials = [
  {
    id: 1,
    content: "SkillSync helped me find a company that was looking for exactly my skill set. Within weeks, I landed interviews at 3 companies that were perfect matches!",
    author: {
      name: 'Priya Sharma',
      role: 'Frontend Developer',
      company: 'TechNova Solutions',
      imageUrl: 'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=100',
    },
  },
  {
    id: 2,
    content: "I was looking to transition to a new industry and wasn't sure which companies would value my transferable skills. SkillSync made this process incredibly easy.",
    author: {
      name: 'Rahul Patel',
      role: 'Product Manager',
      company: 'RetailX',
      imageUrl: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=100',
    },
  },
  {
    id: 3,
    content: "The skill matching algorithm is impressive. It helped me discover companies I hadn't considered before but were actually perfect for my unique skill combination.",
    author: {
      name: 'Ananya Gupta',
      role: 'Data Scientist',
      company: 'HealthTech Innovations',
      imageUrl: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100',
    },
  },
];

const TestimonialSection: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Success Stories
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Hear from professionals who found their perfect match using SkillSync.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-white rounded-lg shadow-md p-6 flex flex-col h-full border border-gray-100 hover:shadow-lg transition-shadow"
            >
              <div className="flex-1">
                <svg className="h-8 w-8 text-blue-500 mb-4" fill="currentColor" viewBox="0 0 32 32">
                  <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
                </svg>
                <p className="text-gray-700 mb-6 italic">"{testimonial.content}"</p>
              </div>
              <div className="flex items-center mt-4">
                <img
                  className="h-12 w-12 rounded-full object-cover"
                  src={testimonial.author.imageUrl}
                  alt={testimonial.author.name}
                />
                <div className="ml-4">
                  <h4 className="text-sm font-medium text-gray-900">{testimonial.author.name}</h4>
                  <div className="text-sm text-gray-600">
                    {testimonial.author.role}, {testimonial.author.company}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a
            href="#"
            className="inline-flex items-center text-blue-800 font-medium hover:text-blue-900"
          >
            Read more success stories
            <svg
              className="ml-2 h-5 w-5"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
              aria-hidden="true"
            >
              <path
                fillRule="evenodd"
                d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z"
                clipRule="evenodd"
              />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;