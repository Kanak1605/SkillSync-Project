import React from 'react';
import { ArrowRight } from 'lucide-react';
import Button from '../common/Button';

const Hero: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-blue-900 to-blue-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Connect Your Skills to Companies That Need Them
            </h1>
            
            <p className="text-lg md:text-xl text-blue-100 leading-relaxed max-w-lg">
              SkillSync helps you discover companies in India that are looking for professionals with your exact skill set. Find your perfect match today.
            </p>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button 
                variant="accent" 
                size="lg"
                rightIcon={<ArrowRight />}
              >
                Get Started
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                className="border-white text-white hover:bg-white/10"
              >
                Learn More
              </Button>
            </div>
            
            <div className="pt-2">
              <p className="text-blue-200 text-sm">
                Trusted by professionals from top companies like
              </p>
              <div className="flex space-x-6 mt-3">
                <span className="text-white font-semibold">Google</span>
                <span className="text-white font-semibold">Microsoft</span>
                <span className="text-white font-semibold">Infosys</span>
                <span className="text-white font-semibold">TCS</span>
              </div>
            </div>
          </div>
          
          <div className="hidden lg:block relative">
            <div className="aspect-w-4 aspect-h-3 rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Professional looking at laptop"
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="absolute -bottom-6 -left-6 bg-white rounded-lg shadow-xl p-4 w-48">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span className="text-sm font-medium text-gray-900">Skills Matched</span>
              </div>
              <div className="text-2xl font-bold text-blue-800">93%</div>
              <div className="text-sm text-gray-600">Perfect match found!</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;