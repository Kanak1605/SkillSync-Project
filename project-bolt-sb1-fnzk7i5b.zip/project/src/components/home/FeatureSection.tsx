import React from 'react';
import { Zap, Search, Building, BarChart } from 'lucide-react';

const features = [
  {
    name: 'Skill Matching',
    description: 'Our advanced algorithm matches your skills with companies that are actively looking for professionals with your expertise.',
    icon: Zap,
    color: 'bg-blue-100 text-blue-800',
  },
  {
    name: 'Company Discovery',
    description: 'Discover companies in India across various industries that align with your professional skills and career goals.',
    icon: Building,
    color: 'bg-teal-100 text-teal-800',
  },
  {
    name: 'Job Position Insights',
    description: 'Get detailed information about open positions that match your skills at companies across India.',
    icon: Search,
    color: 'bg-orange-100 text-orange-800',
  },
  {
    name: 'Skill Analytics',
    description: 'Understand which of your skills are in high demand and which additional skills could increase your employability.',
    icon: BarChart,
    color: 'bg-purple-100 text-purple-800',
  },
];

const FeatureSection: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            How SkillSync Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our platform uses intelligent matching to connect your skills with companies that need them.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="relative p-6 bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
              <div className={`inline-flex items-center justify-center rounded-md p-3 mb-4 ${feature.color}`}>
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.name}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 bg-gray-50 rounded-2xl overflow-hidden shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 md:p-12 flex items-center">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  Why Use SkillSync?
                </h3>
                <div className="space-y-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-lg text-gray-700">Save time looking for companies that value your skills</p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-lg text-gray-700">Discover companies you might not have otherwise considered</p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-lg text-gray-700">Understand which skills to develop for better opportunities</p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-lg text-gray-700">Focus on companies that specifically need your expertise</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="hidden lg:block">
              <img
                src="https://images.pexels.com/photos/3184357/pexels-photo-3184357.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Team working together"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;