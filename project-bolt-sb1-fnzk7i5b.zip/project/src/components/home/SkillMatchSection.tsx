import React, { useState } from 'react';
import { MapPin, Building, Filter } from 'lucide-react';
import SkillSelector from '../skills/SkillSelector';
import { Skill } from '../../types';
import { getCompaniesBySkills } from '../../data/companies';
import CompanyCard from '../companies/CompanyCard';
import Button from '../common/Button';

const LOCATIONS = ['All Locations', 'Bangalore', 'Mumbai', 'Delhi', 'Hyderabad', 'Pune', 'Chennai'];

const SkillMatchSection: React.FC = () => {
  const [selectedSkills, setSelectedSkills] = useState<Skill[]>([]);
  const [filteredCompanies, setFilteredCompanies] = useState(getCompaniesBySkills([]));
  const [location, setLocation] = useState('All Locations');
  const [searching, setSearching] = useState(false);

  const handleSearch = () => {
    setSearching(true);
    
    // Get the IDs of selected skills
    const skillIds = selectedSkills.map(skill => skill.id);
    
    // Get companies by skills
    let companies = getCompaniesBySkills(skillIds);
    
    // Filter by location if needed
    if (location !== 'All Locations') {
      companies = companies.filter(company => 
        company.location === location
      );
    }
    
    setFilteredCompanies(companies);
    
    // Simulate loading
    setTimeout(() => {
      setSearching(false);
    }, 800);
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Find Companies That Match Your Skills
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Input your skills and discover companies in India that are looking for professionals with your expertise.
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-7">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Your Skills
              </label>
              <SkillSelector
                selectedSkills={selectedSkills}
                onChange={setSelectedSkills}
                placeholder="Search for skills (e.g., React, Python, Project Management)"
              />
            </div>
            
            <div className="md:col-span-3">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Location
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <select
                  className="block w-full pl-10 pr-10 py-2.5 border border-gray-300 bg-white rounded-lg shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                >
                  {LOCATIONS.map((loc) => (
                    <option key={loc} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="md:col-span-2 flex items-end">
              <Button
                variant="primary"
                size="lg"
                fullWidth
                isLoading={searching}
                onClick={handleSearch}
              >
                Search
              </Button>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900">
              {searching ? (
                'Searching for matches...'
              ) : filteredCompanies.length ? (
                `${filteredCompanies.length} Matching Companies`
              ) : (
                'All Companies'
              )}
            </h3>
            
            <button className="flex items-center text-sm text-gray-600 hover:text-blue-800">
              <Filter size={16} className="mr-1" />
              Filter Results
            </button>
          </div>
          
          <div className="space-y-6">
            {filteredCompanies.length ? (
              filteredCompanies.map((company) => (
                <CompanyCard
                  key={company.id}
                  company={company}
                  highlightSkills={selectedSkills.map(skill => skill.id)}
                />
              ))
            ) : (
              <div className="text-center py-16 bg-white rounded-lg border border-gray-200">
                <Building size={48} className="mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No companies found</h3>
                <p className="text-gray-600 max-w-md mx-auto">
                  Try adjusting your skill selection or location filters to see more results.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillMatchSection;